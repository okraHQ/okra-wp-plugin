<div class="logo">
    <img width=100 src='<?php echo plugins_url("/" . PLUGIN_URI . "/assets/images/okra-logo.png") ?>'>
</div>
